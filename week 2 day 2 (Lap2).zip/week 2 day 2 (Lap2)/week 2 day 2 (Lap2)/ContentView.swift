//
//  ContentView.swift
//  week 2 day 2 (Lap2)
//
//  Created by Alanoud  on 13/01/1445 AH.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        let sports : Array<String> = [
            " Strong Benchmark" ,
            "Statr Up Benchmark",
            "Lean Fit Benchmark",
            "Run Read"
        ]
        let sportList:Array<ContentView>
        VStack {
            
            Text("FIREFIT")
                .frame(maxWidth:.infinity)
                .font(.largeTitle)
            
            ScrollView(.horizontal){
                HStack{
                    ForEach(sportList){
                        sportList in Button(
                            action:{
                                
                            }, label: {
                                Text(sportList)
                                    .padding(.vertical,8)
                                    .padding(.horizontal,16)
                                    .background(Color.gray.opacity(0.3))
                                    .background(Color.black)
                                    .cornerRadius(12)
                            }
                        )
                    }
                }
            }
            Image("sport")
                .resizable()
                .frame(width: 200, height: 200)
                .padding()
                .opacity(0.3)
            
            NavigationLink(destination:{
                Text("sport view")
            },
                           label: {
                Text("NEXT")
            }
            )
        }
        
        
    }
                struct ContentView_Previews: PreviewProvider {
                    static var previews: some View {
                        ContentView()
                    }
                }
            }
        
    


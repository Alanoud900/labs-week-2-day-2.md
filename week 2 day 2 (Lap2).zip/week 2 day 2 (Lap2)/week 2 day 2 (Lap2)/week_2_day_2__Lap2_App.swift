//
//  week_2_day_2__Lap2_App.swift
//  week 2 day 2 (Lap2)
//
//  Created by Alanoud  on 13/01/1445 AH.
//

import SwiftUI

@main
struct week_2_day_2__Lap2_App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
